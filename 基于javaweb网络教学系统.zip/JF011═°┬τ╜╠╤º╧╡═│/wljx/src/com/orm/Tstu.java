
package com.orm;

public class Tstu
{
	private int id;
	private String xuehao;
	private String name1;
	private String sex;
	private int age;
    private int banji_id;
    private String ruxueshijian;
    
    private String banji_name;

	public int getAge()
	{
		return age;
	}

	public void setAge(int age)
	{
		this.age = age;
	}


	public String getBanji_name()
	{
		return banji_name;
	}

	public void setBanji_name(String banji_name)
	{
		this.banji_name = banji_name;
	}

	public int getBanji_id()
	{
		return banji_id;
	}

	public void setBanji_id(int banji_id)
	{
		this.banji_id = banji_id;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getName1()
	{
		return name1;
	}

	public void setName1(String name1)
	{
		this.name1 = name1;
	}

	public String getRuxueshijian()
	{
		return ruxueshijian;
	}

	public void setRuxueshijian(String ruxueshijian)
	{
		this.ruxueshijian = ruxueshijian;
	}

	public String getSex()
	{
		return sex;
	}

	public void setSex(String sex)
	{
		this.sex = sex;
	}

	public String getXuehao()
	{
		return xuehao;
	}

	public void setXuehao(String xuehao)
	{
		this.xuehao = xuehao;
	}
    
}
